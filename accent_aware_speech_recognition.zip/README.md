# Accent-Aware Speech Recognition System
This project uses deep learning to perform speech recognition, considering accent variability.
It leverages Wav2Vec2 and ECAPA-TDNN models.

## Installation
1. Install dependencies: 
```
pip install -r requirements.txt
```
2. Run the server:
```
python app.py
```
3. Send a POST request to /transcribe with an audio file.

## API Endpoint
- `/transcribe`: Accepts a POST request with an audio file and returns transcription and speaker embedding.

